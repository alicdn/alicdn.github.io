'''先在宝塔面板中安装启动nginx、redis、mariadb/mysql5.5及以上版本，新建数据库并设置数据库密码，
然后修改manage.py里的mysql+pymysql://root:密码@127.0.0.1、修改manage.py里的DB_PASS、修改simdht_worker.py里的DB_PASS、修改sphinx.conf里的sql_pass，再执行下面的命令'''
#此文档中默认程序目录是/root/zsky，如果你使用LNMP/oneinstack/宝塔等面板请根据具体情况修改命令中的目录地址
#设置时区
\cp -rpf /usr/share/zoneinfo/Asia/Chongqing /etc/localtime
#关闭防火墙
systemctl stop firewalld.service  
systemctl disable firewalld.service    
#优化内核参数
cat << EOF > /etc/sysctl.conf
net.ipv4.tcp_syn_retries = 1
net.ipv4.tcp_synack_retries = 1
net.ipv4.tcp_keepalive_time = 600
net.ipv4.tcp_keepalive_probes = 3
net.ipv4.tcp_keepalive_intvl =15
net.ipv4.tcp_retries2 = 5
net.ipv4.tcp_fin_timeout = 2
net.ipv4.tcp_max_tw_buckets = 36000
net.ipv4.tcp_tw_recycle = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_max_orphans = 32768
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_max_syn_backlog = 16384
net.ipv4.tcp_wmem = 8192 131072 16777216
net.ipv4.tcp_rmem = 32768 131072 16777216
net.ipv4.tcp_mem = 786432 1048576 1572864
net.ipv4.ip_local_port_range = 1024 65000
net.ipv4.ip_conntrack_max = 65536
net.ipv4.netfilter.ip_conntrack_max=65536
net.ipv4.netfilter.ip_conntrack_tcp_timeout_established=180
net.core.somaxconn = 16384
net.core.netdev_max_backlog = 16384
vm.overcommit_memory = 1
net.core.somaxconn = 511
EOF
/sbin/sysctl -p /etc/sysctl.conf
/sbin/sysctl -w net.ipv4.route.flush=1
echo 'ulimit -HSn 65536' >> /etc/rc.local
echo 'ulimit -HSn 65536' >>/root/.bash_profile
echo '*  soft  nofile 65536' >> /etc/security/limits.conf
echo '*  hard  nofile 65536' >> /etc/security/limits.conf
ulimit -HSn 65536
#安装必须组件和库(不安装数据库)
cd /root/zsky
yum -y install wget gcc gcc-c++ python-devel 
yum -y install psmisc net-tools lsof epel-release
yum -y install python-pip
pip install --upgrade pip
pip install --upgrade setuptools==30.1.0
pip install -r requirements.txt
#如果你使用的是linode的主机,请取消下面4行的注释
#wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
#wget -qO /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-7.repo
#yum clean metadata
#yum makecache
#创建女优、番号文件夹
mkdir -p /root/zsky/uploads  /root/zsky/uploads/nvyou  /root/zsky/uploads/fanhao
#如果使用其他机器做反代，需要把gunicorn.service里面的127.0.0.1:8000改为0.0.0.0:8000再执行下面的命令
#注册为服务
\cp -rpf systemctl/gunicorn.service  systemctl/indexer.service  systemctl/searchd.service /etc/systemd/system
systemctl daemon-reload	
#创建表
python manage.py init_db
#创建管理员，按照提示输入管理员用户名、密码、邮箱
python manage.py create_user
#如果使用其他机器做反代，忽略下面关于nginx的命令
#在宝塔面板里新增网站-反向代理-目标URL http://127.0.0.1:8000 -“启用反向代理”，配置文件可以参考nginx.conf
#重载nginx设置
nginx -s reload
#启动后端gunicorn+gevent,开启日志记录
systemctl start gunicorn
systemctl enable gunicorn
#编译安装sphinx-jieba
yum -y install git gcc cmake automake g++
git clone http://gitee.com/strwei/sphinx-jieba
cd sphinx-jieba
git submodule update --init --recursive
./configure --prefix=/usr/local/sphinx-jieba
\cp -r cppjieba/include/cppjieba src/ 
\cp -r cppjieba/deps/limonp src/ 
make install
\cp -r cppjieba/dict/* /usr/local/sphinx-jieba/etc/ 
cd /usr/local/sphinx-jieba/
\cp etc/jieba.dict.utf8 etc/xdictjieba.dict.utf8
\cp etc/user.dict.utf8 etc/xdictuser.dict.utf8
\cp etc/hmm_model.utf8 etc/xdicthmm_model.utf8
\cp etc/idf.utf8 etc/xdictidf.utf8
\cp etc/stop_words.utf8 etc/xdictstop_words.utf8
#启动爬虫,开启日志并在后台运行
nohup python /root/zsky/simdht_worker.py >/root/zsky/spider.log 2>&1& 
#启动索引和搜索进程
systemctl start indexer	
systemctl enable indexer
systemctl start searchd	
systemctl enable searchd
#设置开机自启动, 优化redis参数
chmod +x /etc/rc.local
echo "systemctl start  redis.service" >> /etc/rc.local
echo "systemctl start  gunicorn.service" >> /etc/rc.local
echo "systemctl start  indexer.service" >> /etc/rc.local
echo "systemctl start  searchd.service" >> /etc/rc.local
echo "nohup python /root/zsky/simdht_worker.py>/root/zsky/spider.log 2>&1&" >> /etc/rc.local
echo "echo never > /sys/kernel/mm/transparent_hugepage/enabled" >> /etc/rc.local
#设置计划任务,每天早上5点进行主索引
yum -y install  vixie-cron crontabs
systemctl start crond.service
systemctl enable crond.service
crontab -l > /tmp/crontab.bak
echo '0 5 * * * /usr/local/sphinx-jieba/bin/indexer -c /root/zsky/sphinx.conf film --rotate&&/usr/local/sphinx-jieba/bin/searchd --config /root/zsky/sphinx.conf' >> /tmp/crontab.bak
echo '0 4 * * * python /root/zsky/map.py' >> /tmp/crontab.bak
cd /root/zsky
chmod +x zsky-reboot.sh
echo '0 */1 * * * sh /root/zsky/zsky-reboot.sh' >> /tmp/crontab.bak
crontab /tmp/crontab.bak
#如果使用其他机器做反代，忽略下面关于nginx的命令
#查看当前进程运行状态
pgrep -l nginx
pgrep -l searchd
pgrep -l gunicorn
#进入mysql数据库，导入sql文件
source /root/zsky/search_keywords.sql;
source /root/zsky/search_actors.sql;
#上传nvyou.zip到/root/zsky目录，解压nvyou.zip
cd /root/zsky
unzip nvyou.zip

'''
常见问题与回答：

程序默认数据库密码123456
修改simdht_worker.py里的max_node_qsize的大小调节爬取速度（队列大小）
执行 python manage.py init_db     创建表/平滑升级表结构
执行 python manage.py create_user 创建管理员
执行 python manage.py changepassword 修改管理员密码
执行 systemctl start gunicorn  启动网站
执行 systemctl restart mariadb  重新启动数据库
执行 systemctl status gunicorn  查看gunicorn运行状态
执行 systemctl restart gunicorn   重新启动网站
执行 systemctl restart indexer  手动重新索引
执行 systemctl start searchd  开启搜索进程
执行 systemctl status searchd  查看搜索进程运行状态
执行 systemctl restart searchd   重新启动搜索进程

安装过程中会提示输入管理员用户名、密码、邮箱，输入后耐心等待即可访问 http://IP
后台地址 http://IP/admin
Q：如何修改后台地址？
A：修改manage.py中的以下语句中的url=后面的地址：
admin = Admin(app,name='管理中心',base_template='admin/my_master.html',index_view=MyAdminIndexView(name='首页',template='admin/index.html',url='/fucku'))
#重启systemctl restart gunicorn
Q：拿到手如何对主机进行基本的评测？
A：查看主机CPU、内存、系统、IO性能、带宽
wget -qO- bench.sh|bash
查看服务器硬盘通电时间
yum -y install smartmontools
smartctl -A /dev/sda
#结果中的Power_On_Hours就是通电时间，单位为小时
如果发现通电时间过长，最好找机房商量更换硬盘。
Q：如何实现远程主机反向代理本程序？
A：修改本机的/etc/systemd/system/gunicorn.service其中的127.0.0.1:8000修改为0.0.0.0:8000然后执行systemctl daemon-reload
本程序所在主机不开启nginx，远程主机开启nginx，配置反向代理，绑定域名，配置文件参考程序内的nginx.conf ，即可使用域名正常访问。
Q：如何给番号/女优添加图片、评分？
A：后台-番号-番号图片-上传图片（图片名不能重复）,或者后台-女优-女优图片-上传图片（图片名不能重复）
后台-热门番号-新建， 在“图片”选项中输入/uploads/fanhao/图片地址 ， 以及片名、评分、显示顺序 , 
后台-女优大全-新建， 在“图片”选项中输入/uploads/fanhao/图片地址 ， 以及片名、评分、显示顺序 ,
在templates/index.html里调用{{k.pic}}代表番号的图片地址,{{k.score}}代表番号的评分，调用{{pic.pic}}代表女优图片地址,{{pic.score}}代表女优评分
Q：怎么限制/提高爬取速度？
A：修改simdht_worker.py里的max_node_qsize=后面的数字，越大爬取越快，越小爬取越慢
Q：觉得数据库空密码不安全，怎么修改数据库密码？
A：执行mysqladmin -uroot -p password 123456!@#$%^     ，将提示输入当前密码，123456!@#$%^是新密码
Q：修改数据库密码后怎么修改程序里的配置？
A：修改manage.py里的mysql+pymysql://root:密码@127.0.0.1、修改manage.py里的DB_PASS、修改simdht_worker.py里的DB_PASS、修改sphinx.conf里的sql_pass
Q：怎么确定爬虫是在正常运行？
A：执行 ps -ef|grep -v grep|grep simdht 如果有结果说明爬虫正在运行
Q：更新版本/模板后怎么立即生效？
A：执行 systemctl restart gunicorn 重启gunicorn
Q：为什么首页统计的数据远远小于后台的数据？
A：在数据量变大后，索引将占用CPU 100%，非常影响用户访问网站，为了最小程度减小此影响 默认设置为每天早上5点更新索引，你想现在更新爬取结果的话，手动执行索引 systemctl restart indexer ，需要注意的是，数据量越大 索引所耗费时间越长
Q：如何查看索引是否成功？
A：执行 systemctl status indexer 可以看到索引记录
Q：觉得索引速度有点慢，怎么加快？
A：修改sphinx.conf里面的mem_limit = 512M ，根据你的主机的内存使用情况来修改，越大索引越快，最大可以设置2048M
Q：想确定搜索进程是否正常运行
A：执行 systemctl status searchd ，如果是绿色的running说明搜索进程完全正常
Q：如何备份数据库？
A：执行 mysqldump -uroot -p zsky>/root/zsky.sql  导出数据库  //将提示输入当前密码，直接回车即可，数据库导出后存在/root/zsky.sql
Q：数据库备份后，现在重新安装了程序，如何导入旧数据？
A：执行 mysql -uroot -p zsky</root/zsky.sql       //假设你的旧数据库文件是/root/zsky.sql，将提示输入当前密码，直接回车即可
Q：我以前使用的搜片大师/手撕包菜，可以迁移过来吗？
A：程序在开发之初就已经考虑到从这些程序迁移过来的问题，所以你不用担心，完全可以无缝迁移。
Q：网站经常收到版权投诉，有没有好的解决办法？
A：除了删除投诉的影片数据外，你可以使用前端Nginx与后端gunicorn+爬虫+数据库+索引在不同主机上的模式，甚至多前端+DNS智能解析模式，这样即使前端被主机商强行封机，也能保证后端数据的安全
Q：我的流量超过10W PV！用gunicorn+gevent架构，查看错误日志 有时候会连不上数据库，怎么办？
A：我们还有更好的web架构，只是不能注册为服务，要用命令执行。保证在硬件和带宽足够的情况下，50W PV内没问题。所以你只需要放心做流量即可。
Q：如何一次性修改站点名字，在模板中全部生效？
A：修改manage.py的{{sitename}}=""的内容
Q：如何修改URL规则？
A：修改@app.route后面引号内的内容，除了<变量>内容之外，都可以修改
Q：修改模板后重启gunicorn也没有生效？
A：刷新redis缓存
redis-cli
#进入redis的命令行
flushdb
#刷新全部缓存
systemctl restart gunicorn
#重启gunicorn
Q：查看爬虫当前线程数？
A：
ps -ef|grep simdht|awk '{print $2}'|grep -v grep|xargs ps hH |wc -l
或
ps -xH|grep simdht|grep -v grep|wc -l
Q：如何生成地图？
A：修改map.py里的域名、数据库信息，然后执行python map.py生成地图，这个脚本是直接从mysql数据库读取数据，比搜索结果的数据要多，所以最好是先生成地图再索引
Q：手动操作的命令？
A：
杀死爬虫
ps -ef|grep simdht_worker.py|grep -v grep|awk '{print $2}'|xargs kill -9
杀死并启动爬虫
ps -ef|grep simdht_worker.py|grep -v grep|awk '{print $2}'|xargs kill -9
cd /root/zsky
nohup python simdht_worker.py>/root/zsky/spider.log 2>&1&
手动索引
/usr/local/sphinx-jieba/bin/indexer -c /root/zsky/sphinx.conf film --rotate
手动启动搜索进程
/usr/local/sphinx-jieba/bin/searchd --config ~/zsky/sphinx.conf
手动启动gunicorn
/usr/bin/gunicorn -k gevent --access-logfile zsky.log --error-logfile zsky_err.log --access-logformat '%({X-Real-IP}i)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"' manage:app -b 127.0.0.1:8000 -w 4
Q：如何最简单的实现一库多站（模板、程序都不同）？
A：
假设第一个站主程序是manage.py 静态文件目录是static 模板文件目录是templates
1.修改第二个站的程序名、静态目录名、模板目录名，比如分别修改为manage2.py,static2,templates2
2.修改manage2.py为如下：
app = Flask(__name__)修改为
app = Flask(__name__,template_folder='templates2',static_folder='static2')
3.manage2.py填写正确的数据库信息
#如果使用其他机器做反代，需要把gunicorn2.service里面的127.0.0.1:8001改为0.0.0.0:8001再执行下面的命令
4.把gunicorn2.service拷贝到/etc/systemd/system目录
5.执行systemctl daemon-reload
然后执行systemctl start gunicorn2即可运行第二个站
其他命令:  systemctl restart gunicorn2 	//修改模板或者覆盖程序后重启第二个站的web服务
'''