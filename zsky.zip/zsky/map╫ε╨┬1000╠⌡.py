# coding:utf-8
from __future__ import print_function
import datetime
import os
import MySQLdb
import MySQLdb.cursors

DB_HOST = '127.0.0.1'
DB_NAME_MYSQL = 'zsky'
DB_PORT_MYSQL = 3306
DB_USER = 'root'
DB_PASS = '6f81f112dbe1efc4'
DB_CHARSET = 'utf8mb4'
domain = "https://www.xxx.com/"
mtime = datetime.datetime.now().strftime('%Y-%m-%d')

if not os.path.exists('/root/zsky/map'):
    os.mkdir('/root/zsky/map')
    print("成功创建/root/zsky/map文件夹")
conn = MySQLdb.connect(host=DB_HOST, port=DB_PORT_MYSQL, user=DB_USER, passwd=DB_PASS, db=DB_NAME_MYSQL,
                       charset=DB_CHARSET, cursorclass=MySQLdb.cursors.DictCursor)
curr = conn.cursor()
newest_sql = 'SELECT info_hash FROM search_hash order by id desc limit 1000'
curr.execute(newest_sql)
newest = curr.fetchall()
# 如果你的内容页格式有修改，也需要在这里跟着修改
url = "".join(['<url>'
               '<loc>{}hash/{}.html</loc>'
               '<lastmod>{}</lastmod>'
               '<changefreq>daily</changefreq>'
               '<priority>0.8</priority>'
               '</url>'.format(domain, info_hash['info_hash'], mtime) for info_hash in newest])
urlset = '<?xml version="1.0" encoding="utf-8"?>' \
             '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' \
             '{}' \
             '</urlset>'.format(url)
with open('/root/zsky/map/sitemap.xml', 'w') as f:
    f.write(urlset)
    f.close()
    print("成功创建/root/zsky/sitemap.xml")
curr.close()
conn.close()
